import { redirect } from "next/navigation"

/** The old course list. The prototype has one Student View page with a course select, so this redirects there. */
export default function Page() {
  redirect("/student")
}
