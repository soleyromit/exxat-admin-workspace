import { redirect } from "next/navigation"

/** The tabs are one page now: this old route redirects to /library/skills?tab=settings. */
export default function Page() {
  redirect("/library/skills?tab=settings")
}
