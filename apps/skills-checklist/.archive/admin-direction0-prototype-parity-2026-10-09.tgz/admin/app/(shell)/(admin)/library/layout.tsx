import * as React from "react"

/**
 * Library pass-through. The Skills Library is ONE page (components/library/library-page.tsx: header, five tabs, content), so
 * there is no shared chrome here: skills/new, skills/[id]/configure and import own their frames.
 */
export default function LibraryLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
