import { redirect } from "next/navigation"
import { ROUTES } from "@/lib/skills-routes"

/** Deep link for the configure wizard: redirects to the Skills Library page, which opens the dialog (P-08). */
export default async function Page({ params }: { params: Promise<{ skillId: string }> }) {
  const { skillId } = await params
  redirect(`${ROUTES.skills}?dialog=configure&skill=${encodeURIComponent(skillId)}`)
}
