import { redirect } from "next/navigation"
import { ROUTES } from "@/lib/skills-routes"

/**
 * The review is now step 2 of the Import dialog (P-06), held in the dialog's own state. An old review link opens the dialog at
 * its first step; any draft stays in the store until it is confirmed or discarded.
 */
export default function Page() {
  redirect(`${ROUTES.skills}?dialog=import`)
}
