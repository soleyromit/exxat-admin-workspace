import { redirect } from "next/navigation"
import { ROUTES } from "@/lib/skills-routes"

export default function Library() {
  redirect(ROUTES.skills)
}
