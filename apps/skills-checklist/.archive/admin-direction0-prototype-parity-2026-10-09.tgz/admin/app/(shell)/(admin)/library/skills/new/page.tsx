import { redirect } from "next/navigation"
import { ROUTES } from "@/lib/skills-routes"

/**
 * Deep link for the Add a skill dialog. The prototype's configure and add flows are dialogs on the Skills Library page
 * (docs/build/prototype-parity.md P-07, P-08), so this route redirects there with the dialog URL contract
 * (`components/library/dialog-bridge.ts`).
 */
export default function Page() {
  redirect(`${ROUTES.skills}?dialog=add`)
}
