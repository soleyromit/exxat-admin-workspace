import { redirect } from "next/navigation"
import { EMPTY_PARAMS, toSearch } from "@/components/reporting/report-params"
import { ROUTES } from "@/lib/skills-routes"

// S-03 deep link: the evidence ledger for one student and skill, as the second level of the Overview rail.
export default async function Page({ params }: { params: Promise<{ studentId: string; skillId: string }> }) {
  const { studentId, skillId } = await params
  redirect(`${ROUTES.overview}${toSearch({ ...EMPTY_PARAMS, student: studentId, skill: skillId })}`)
}
