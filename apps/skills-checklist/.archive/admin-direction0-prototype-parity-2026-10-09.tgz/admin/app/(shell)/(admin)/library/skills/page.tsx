import { Suspense } from "react"
import { LibraryPage } from "@/components/library/library-page"

/** Skills Library (S-04 to S-07): one page, five tabs (?tab=). Filters and dialogs live in the query string, so Suspense. */
export default function Page() {
  return (
    <Suspense fallback={null}>
      <LibraryPage />
    </Suspense>
  )
}
