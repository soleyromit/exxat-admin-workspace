import { redirect } from "next/navigation"
import { EMPTY_PARAMS, toSearch } from "@/components/reporting/report-params"
import { ROUTES } from "@/lib/skills-routes"

// S-02 deep link. The student record is a rail on the Overview (docs/build/contracts/S-02 §7, proposal: rail with a deep-link URL),
// so this route redirects to the Overview with the rail open at the student level. The URL stays shareable.
export default async function Page({ params }: { params: Promise<{ studentId: string }> }) {
  const { studentId } = await params
  redirect(`${ROUTES.overview}${toSearch({ ...EMPTY_PARAMS, student: studentId })}`)
}
