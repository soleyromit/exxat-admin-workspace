import { redirect } from "next/navigation"
import { ROUTES } from "@/lib/skills-routes"

/** Deep link for the Import skills dialog: redirects to the Skills Library page, which opens it (P-06). */
export default function Page() {
  redirect(`${ROUTES.skills}?dialog=import`)
}
