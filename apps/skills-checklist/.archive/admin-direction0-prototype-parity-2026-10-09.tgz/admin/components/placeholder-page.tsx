import { Badge } from "@exxatdesignux/ui/components/ui/badge"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@exxatdesignux/ui/components/ui/card"
import type { PlaceholderMeta } from "@/lib/skills-routes"

/**
 * Scaffold-only page body. One h1, one purpose line (copy from docs/ux/09), and the confirmed
 * contract this surface will be built from. No data, no feature logic. Replace per surface.
 */
export function PlaceholderPage({ meta }: { meta: PlaceholderMeta }) {
  return (
    <div className="mx-auto flex w-full max-w-5xl flex-col gap-6 p-6">
      <header className="flex flex-col gap-1">
        <h1 className="text-2xl font-semibold text-foreground">{meta.title}</h1>
        <p className="text-sm text-muted-foreground">{meta.subtitle}</p>
      </header>
      <Card>
        <CardHeader>
          {/* asChild: the DS CardTitle is an h3; under the page h1 the next level is h2 (WCAG heading order). */}
          <CardTitle asChild className="flex items-center gap-2 text-base">
            <h2>
              Not built yet
              <Badge variant="outline">{meta.surface}</Badge>
            </h2>
          </CardTitle>
          <CardDescription>
            This surface is built from its confirmed contract: {meta.contract}
          </CardDescription>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground">
          The scaffold provides the shell and route only.
        </CardContent>
      </Card>
    </div>
  )
}
