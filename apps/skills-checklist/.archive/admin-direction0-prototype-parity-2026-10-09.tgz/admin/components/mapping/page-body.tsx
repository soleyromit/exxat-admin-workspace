import * as React from "react"
import { PageHeader } from "@exxatdesignux/ui/components/ui/page-header"

/**
 * Page chrome for Course Mapping and Review & Approve: the DS PageHeader (title + one-line purpose; the breadcrumb lives
 * in the shell's utility bar) above a content column with the prototype's page rhythm (16px between blocks, 20x24 padding).
 */
export function PageBody({ title, subtitle, children }: { title: string; subtitle: string; children?: React.ReactNode }) {
  return (
    <div className="flex w-full flex-col gap-4 px-6 py-5">
      <PageHeader title={title} subtitle={subtitle} className="px-0 pt-0 pb-0 lg:px-0 lg:pt-0 lg:pb-0" />
      {children}
    </div>
  )
}
