"use client"

/**
 * The URL contract between the Skills Library page and the Add skill / Configure / Import dialogs
 * (`components/configure/dialog-host.tsx`, mounted by `components/library/library-page.tsx`):
 *
 *   /library/skills?dialog=add
 *   /library/skills?dialog=configure&skill=<skillId>
 *   /library/skills?dialog=import
 *
 * The openers always change the URL; the host reads it and opens the dialog in place. The old full-page routes
 * (skills/new, skills/[id]/configure, import) are redirects to these URLs.
 */
import * as React from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { ROUTES } from "@/lib/skills-routes"

export type LibraryDialogName = "add" | "configure" | "import"

export const LIBRARY_PATH = ROUTES.skills

export interface LibraryDialogState {
  dialog: LibraryDialogName | null
  skillId: string | null
}

/** Which dialog the URL asks for. */
export function useLibraryDialogState(): LibraryDialogState {
  const params = useSearchParams()
  const raw = params?.get("dialog") ?? ""
  const dialog = raw === "add" || raw === "configure" || raw === "import" ? raw : null
  return { dialog, skillId: dialog === "configure" ? (params?.get("skill") ?? null) : null }
}

export interface LibraryDialogs {
  openAddSkill: () => void
  openConfigure: (skillId: string) => void
  openImport: () => void
  /** Drops `dialog` and `skill` from the URL, keeping every other query key (filters, tab). */
  close: () => void
}

export function useLibraryDialogs(): LibraryDialogs {
  const router = useRouter()
  const params = useSearchParams()
  const query = params?.toString() ?? ""

  const withDialog = React.useCallback(
    (dialog: LibraryDialogName | null, skillId?: string) => {
      const sp = new URLSearchParams(query)
      sp.delete("dialog")
      sp.delete("skill")
      if (dialog) sp.set("dialog", dialog)
      if (dialog === "configure" && skillId) sp.set("skill", skillId)
      const q = sp.toString()
      return q ? `${LIBRARY_PATH}?${q}` : LIBRARY_PATH
    },
    [query],
  )

  return React.useMemo<LibraryDialogs>(
    () => ({
      openAddSkill: () => router.push(withDialog("add")),
      openConfigure: (skillId) => router.push(withDialog("configure", skillId)),
      openImport: () => router.push(withDialog("import")),
      close: () => router.replace(withDialog(null), { scroll: false }),
    }),
    [router, withDialog],
  )
}
