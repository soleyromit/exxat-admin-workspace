import * as React from "react"

/**
 * One page frame for every surface (matches the scaffold's PlaceholderPage): ONE h1, one purpose line, an optional
 * action slot (exactly one filled primary lives here or in the content, never two: cross-cutting §9, ux/08 P-12).
 */
export function PageFrame({ title, subtitle, actions, wide, children }: { title: string; subtitle?: string; actions?: React.ReactNode; wide?: boolean; children?: React.ReactNode }) {
  return (
    <div className={`mx-auto flex w-full flex-col gap-6 p-6 ${wide ? "max-w-7xl" : "max-w-5xl"}`}>
      <header className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex min-w-0 flex-col gap-1">
          <h1 className="text-2xl font-semibold text-foreground">{title}</h1>
          {subtitle ? <p className="text-sm text-muted-foreground">{subtitle}</p> : null}
        </div>
        {actions ? <div className="flex items-center gap-2">{actions}</div> : null}
      </header>
      {children}
    </div>
  )
}

/** A titled region inside a page. The heading is an h2 so the outline stays valid under the page h1. */
export function PageSection({ title, description, children, id }: { title: string; description?: string; children?: React.ReactNode; id?: string }) {
  return (
    <section aria-labelledby={id ? `${id}-heading` : undefined} className="flex flex-col gap-3">
      <div className="flex flex-col gap-0.5">
        <h2 id={id ? `${id}-heading` : undefined} className="text-base font-semibold text-foreground">
          {title}
        </h2>
        {description ? <p className="text-sm text-muted-foreground">{description}</p> : null}
      </div>
      {children}
    </section>
  )
}
