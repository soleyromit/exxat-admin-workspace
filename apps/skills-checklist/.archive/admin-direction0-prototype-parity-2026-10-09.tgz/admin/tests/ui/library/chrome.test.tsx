import * as React from "react"
import { beforeEach, describe, expect, it, vi } from "vitest"
import { screen } from "@testing-library/react"
import userEvent from "@testing-library/user-event"

vi.mock("next/navigation", async () => (await import("./harness")).navigationMock)

import { LibraryPage, libraryTabHref, parseTab } from "@/components/library/library-page"
import {  useLibraryDialogs, useLibraryDialogState } from "@/components/library/dialog-bridge"
import { axeViolations, nav, renderPage, resetWorld } from "./harness"

beforeEach(() => resetWorld())

describe("library page: one page, five tabs (P-04, P-05)", () => {
  it("parses the tab from ?tab= and falls back to Skills; tab hrefs round-trip", () => {
    expect(parseTab(null)).toBe("skills")
    expect(parseTab("nonsense")).toBe("skills")
    for (const t of ["categories", "tags", "settings", "lab-instructors"]) expect(libraryTabHref(parseTab(t))).toBe(`/library/skills?tab=${t}`)
    expect(libraryTabHref("skills")).toBe("/library/skills")
  })

  it("renders one h1, five tabs, the selected tab from the URL, and no second tab's content", async () => {
    resetWorld("/library/skills", "tab=tags")
    const { container } = renderPage(<LibraryPage />)
    expect(await screen.findByRole("heading", { level: 2, name: "Where each tag reaches" })).toBeInTheDocument()
    expect(screen.getAllByRole("heading", { level: 1 })).toHaveLength(1)
    expect(screen.getAllByRole("tab")).toHaveLength(5)
    expect(screen.getByRole("tab", { name: /^Tags \(/ })).toHaveAttribute("aria-selected", "true")
    expect(screen.queryByRole("searchbox", { name: "Search skills" })).toBeNull()
    expect(await axeViolations(container)).toEqual([])
  })

  it("keyboard: arrow keys move along the tab row and open the tab (the page is one route; the URL follows)", async () => {
    const user = userEvent.setup()
    renderPage(<LibraryPage />)
    await screen.findByText("IV Insertion")
    await user.tab()
    expect(screen.getByRole("tab", { name: /^Skills \(/ })).toHaveFocus()
    await user.keyboard("{ArrowRight}")
    expect(screen.getByRole("tab", { name: /^Categories \(/ })).toHaveFocus()
    await user.keyboard("{Enter}")
    expect(nav.push).toHaveBeenCalledWith("/library/skills?tab=categories", { scroll: false })
  })
})

function Probe() {
  const dialogs = useLibraryDialogs()
  const state = useLibraryDialogState()
  return (
    <div>
      <button type="button" onClick={dialogs.openAddSkill}>add</button>
      <button type="button" onClick={() => dialogs.openConfigure("sk-iv")}>configure</button>
      <button type="button" onClick={dialogs.openImport}>import</button>
      <button type="button" onClick={dialogs.close}>close</button>
      <output>{`${state.dialog ?? "none"}|${state.skillId ?? ""}`}</output>
    </div>
  )
}

describe("dialog bridge: the URL contract with the Add skill / Configure / Import dialogs", () => {
  it("opens ?dialog=add | configure&skill= | import on the library page in place, keeping the other keys", async () => {
    resetWorld("/library/skills", "status=unconfigured&q=nas")
    const user = userEvent.setup()
    renderPage(<Probe />)
    await user.click(screen.getByText("add"))
    expect(nav.push).toHaveBeenLastCalledWith("/library/skills?status=unconfigured&q=nas&dialog=add")
    await user.click(screen.getByText("configure"))
    expect(nav.push).toHaveBeenLastCalledWith("/library/skills?status=unconfigured&q=nas&dialog=configure&skill=sk-iv")
    await user.click(screen.getByText("import"))
    expect(nav.push).toHaveBeenLastCalledWith("/library/skills?status=unconfigured&q=nas&dialog=import")
    await user.click(screen.getByText("close"))
    expect(nav.replace).toHaveBeenLastCalledWith("/library/skills?status=unconfigured&q=nas", { scroll: false })
  })

  it("reads the open dialog and skill from the URL", () => {
    resetWorld("/library/skills", "dialog=configure&skill=sk-wound")
    renderPage(<Probe />)
    expect(screen.getByRole("status")).toHaveTextContent("configure|sk-wound")
  })
})
