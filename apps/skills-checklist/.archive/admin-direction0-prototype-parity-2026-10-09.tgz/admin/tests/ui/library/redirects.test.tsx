import { beforeEach, describe, expect, it, vi } from "vitest"

const redirect = vi.fn()
vi.mock("next/navigation", () => ({ redirect: (to: string) => redirect(to) }))

beforeEach(() => redirect.mockClear())

/** The five tab routes were one route each; the library is one page now, so every old URL keeps working. */
describe("old library tab routes redirect to the one library page", () => {
  it.each([
    ["categories", "/library/skills?tab=categories"],
    ["tags", "/library/skills?tab=tags"],
    ["settings", "/library/skills?tab=settings"],
    ["lab-instructors", "/library/skills?tab=lab-instructors"],
  ])("/library/%s -> %s", async (route, target) => {
    const mod = await import(`@/app/(shell)/(admin)/library/${route}/page`)
    mod.default()
    expect(redirect).toHaveBeenCalledWith(target)
  })

  it("/library -> /library/skills", async () => {
    const mod = await import("@/app/(shell)/(admin)/library/page")
    mod.default()
    expect(redirect).toHaveBeenCalledWith("/library/skills")
  })
})
